#include <linux/init.h>
#include <linux/module.h>
#include <linux/proc_fs.h>
#include <asm/uaccess.h>
#include <linux/seq_file.h>
#include <linux/sched.h>


//TODO: necessary additional declarations


static struct proc_dir_entry *pentry;
static struct proc_dir_entry *pdir;
int custom_proc_show(struct seq_file* m, void* p)
{
    //TODO : add your code here
	return 0;
}
int pdemo_open (struct inode * inode, struct file * file)
{
	return single_open(file,custom_proc_show,NULL);
}
ssize_t pdemo_write( struct file *filp,const char __user* ubuf,size_t ucount,loff_t *poff)
{
   //TODO : add your code here   
   return ucount;
}
struct file_operations fops=
{
	.open	 = pdemo_open,
	.release = single_release,
	.read	 = seq_read,
	.llseek  = seq_lseek,
	.write   = pdemo_write,
};
int __init psdemo_init(void)	//init_module
{
	printk("psingle::init--welcome\n");
	pdir=proc_mkdir("sample",NULL);
	pentry=proc_create("mylist",0666,pdir,&fops);
	if(pentry==NULL) {
		printk("failed to create proc entry\n");
		goto error;
	}
	//TODO: any additional code here
	goto success;
error:
	return -EINVAL;
success:
	return 0;

}
void __exit psdemo_exit(void) 	
{
    //TODO: any additional code here
	remove_proc_entry("mylist",pdir);
	remove_proc_entry("sample",NULL);
	printk("psingle demo::exit--bye\n");
}
module_init(psdemo_init);
module_exit(psdemo_exit);
MODULE_AUTHOR("Your Name");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("A Simple Module");
